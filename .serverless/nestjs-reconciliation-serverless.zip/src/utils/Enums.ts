export enum LINK_PRECEDENCE {
  PRIMARY = 'primary',
  SECONDARY = 'secondary',
}
