export class CreateContactDto {
  email: string | null;
  phoneNumber: string | null;
}
